<h1>You View</h1><br>

Simple program to increase YouTube views. Works with live stream too.<br>

You don't need any requirements, cause i already compil it. <br>

<br><br>
<h1>FEATURES</h1> <br>
- Proxy support (free/paid/rotating) <br>
- Live view <br>
- Video view <br>
- Music video view <br>

<h1>How to use ?</h1> <br><br>
1° Copy and paste your youtube link <br>
2° Write the exact title video in search.txt <br>
3° Click on youview.exe <br>
4° Rest is self explanatory

<br><br>
<h1>Website</h1><br><br>
Live logs fetched every 10 seconds and statistics in graphs are available on http://localhost:5000/

